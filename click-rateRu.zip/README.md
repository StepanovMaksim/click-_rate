## Скорость нажатий
https://stepanovmaksim.github.io/click-rate/

Игра с адаптивным дизайном и простой анимацией
